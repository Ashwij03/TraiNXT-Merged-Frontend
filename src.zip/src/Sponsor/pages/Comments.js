import React from "react";
import AppLayout from "./AppLayout";
<<<<<<< HEAD:src/pages/Sponsor/Comments.js
import RoleCommentsView from "../../components/common/RoleCommentsView";
import "../shared/operations/Comments.css";
=======
import RoleCommentsView from "../../shared/components/RoleCommentsView";
import "../../shared/pages/operations/Comments.css";
>>>>>>> 36a9968bf713b2a6fc05eba1b85c72608d656f05:src/Sponsor/pages/Comments.js

export default function CommentsPage() {
  return (
    <AppLayout>
      <RoleCommentsView embedded />
    </AppLayout>
  );
}
