<<<<<<< HEAD:src/pages/Admin/LiveChat.js
import AdminDashboardLayout from "../../components/dashboard/admin/AdminDashboardLayout";
import RoleLiveChatPage from "../../components/common/RoleLiveChatPage";
import ROLES from "../../constants/roles";
import useLiveChatNavigation from "../../hooks/useLiveChatNavigation";
=======
import AdminDashboardLayout from "../components/AdminDashboardLayout";
import RoleLiveChatPage from "../../shared/components/RoleLiveChatPage";
import ROLES from "../../shared/constants/roles";
import useLiveChatNavigation from "../../shared/hooks/useLiveChatNavigation";
>>>>>>> 36a9968bf713b2a6fc05eba1b85c72608d656f05:src/Admin/pages/LiveChat.js

function AdminLiveChat() {
  const { returnFromLiveChat, backLabel } = useLiveChatNavigation("/admin-livechat");

  return (
    <AdminDashboardLayout>
      <RoleLiveChatPage
        role={ROLES.ADMIN}
        onBack={returnFromLiveChat}
        backLabel={backLabel}
      />
    </AdminDashboardLayout>
  );
}

export default AdminLiveChat;
