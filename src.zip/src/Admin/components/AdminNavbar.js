<<<<<<<< HEAD:src/Components/dashboard/admin/AdminNavbar.js
import ROLES from "../../../constants/roles";
import EnterpriseNavbarBase from "../shared/EnterpriseNavbarBase";
========
import ROLES from "../../shared/constants/roles";
import EnterpriseNavbarBase from "../../shared/components/dashboard/shared/EnterpriseNavbarBase";
>>>>>>>> 36a9968bf713b2a6fc05eba1b85c72608d656f05:src/Admin/components/AdminNavbar.js

function AdminNavbar(props) {
  return (
    <EnterpriseNavbarBase
      {...props}
      layoutRole={ROLES.ADMIN}
      liveChatPath="/admin-livechat"
      navbarClassName="admin-navbar enterprise-header--role-branded"
    />
  );
}

export default AdminNavbar;
