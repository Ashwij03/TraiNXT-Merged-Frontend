import React from "react";
import { useLocation } from "react-router-dom";
import {
  FaHome,
  FaBookOpen,
  FaChartBar,
  FaUserFriends,
  FaUniversity,
  FaChartPie,
  FaBell,
  FaCog,
} from "react-icons/fa";
import "./PISidebar.css";
import { getSidebarMenuData } from "./piDashboardService";
import TriaNXTLogo from "../../components/common/TriaNXTLogo";
import RoleStudiesSidebarTree from "../../components/common/RoleStudiesSidebarTree";
import { useRoleStudiesSidebar } from "../../hooks/useRoleStudiesSidebar";

const ICON_MAP = {
  home: FaHome,
  chart: FaChartBar,
  users: FaUserFriends,
  university: FaUniversity,
  pie: FaChartPie,
  bell: FaBell,
  cog: FaCog,
};

function PISidebar({
  selectedPage,
  setSelectedPage,
  isOpen = true,
  onClose,
}) {
  const { pathname } = useLocation();

  const menuData = getSidebarMenuData();

  const {
    studyCount,
    studiesOpen,
    isStudiesActive,
    handleStudiesClick,
  } = useRoleStudiesSidebar({
    onNavigate: onClose,
  });

  const handleStudiesNav = () => {
    handleStudiesClick();

    if (typeof setSelectedPage === "function") {
      setSelectedPage("studies");
    }
  };

  const handleMenuClick = (page) => {
    if (typeof setSelectedPage === "function") {
      setSelectedPage(page);
    }

    if (typeof onClose === "function") {
      onClose();
    }
  };

const getMenuClass = (page) => {
  const routeMap = {
    dashboard: "/pi-dashboard",
    comments: "/pi-comments",
    sitePerformance: "/pi-site-performance",
    recruitment: "/pi-recruitment",
    regulatory: "/pi-regulatory",
    reports: "/pi-reports",
    notifications: "/pi-notifications",
    settings: "/pi-settings",
  };

  const route = routeMap[page];

  const isActive =
    route &&
    (pathname === route || pathname.startsWith(`${route}/`));

  return `menu-item${isActive ? " active-menu" : ""}`;
};

  const mainSections = menuData.sections.filter(
    (section) => section.id !== "dashboard",
  );

  const dashboardSection = menuData.sections.find(
    (section) => section.id === "dashboard",
  );

  return (
    <>
      <div
        className={`pi-sidebar-overlay${isOpen ? " visible" : ""}`}
        onClick={onClose}
      />

      <div className={`sidebar pi-sidebar${isOpen ? " open" : ""}`}>
        <TriaNXTLogo
          size="sidebar"
          className="pi-sidebar-brand"
          onClick={() => handleMenuClick("dashboard")}
        />

        {/* Dashboard */}
        {dashboardSection && (
          <div
            className={getMenuClass(dashboardSection.page)}
            onClick={() => handleMenuClick(dashboardSection.page)}
          >
            <FaHome />
            <span>{dashboardSection.label}</span>
          </div>
        )}

        {/* Studies */}
        <div
          className={`menu-item studies-menu${
            selectedPage === "studies" || isStudiesActive
              ? " active-menu"
              : ""
          }`}
          onClick={handleStudiesNav}
        >
          <FaBookOpen />
          <span>Studies ({studyCount})</span>
        </div>

        {/* Studies submenu */}
        {studiesOpen && (
          <div className="submenu-container pi-studies-tree">
            <RoleStudiesSidebarTree onNavigate={onClose} />
          </div>
        )}

        {/* Other menu items */}
        {mainSections.map((section) => {
          const Icon = ICON_MAP[section.icon] || FaChartBar;

          return (
            <div
              key={section.id}
              className={getMenuClass(section.page)}
              onClick={() => handleMenuClick(section.page)}
            >
              <Icon />
              <span>{section.label}</span>
            </div>
          );
        })}
      </div>
    </>
  );
}

export default PISidebar;