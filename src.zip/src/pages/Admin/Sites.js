// UPDATED: Dynamic sites page wired to adminService localStorage data

import DashboardLayout from "../../components/dashboard/shared/DashboardLayout";
import KPICard from "../../components/dashboard/shared/KPICard";
import DataTable from "../../components/dashboard/shared/DataTable";
import { getSites } from "../../services/adminService";
import "./AdminPage.css";

function Sites() {
  const sites = getSites();
  const activeSites = sites.filter((site) => site.status === "Active").length;
  const totalEnrolled = sites.reduce(
    (sum, site) => sum + Number(site.subjectsEnrolled || 0),
    0
  );

  return (
    <DashboardLayout>
      <div className="admin-page tnxt-compact">
        <div className="admin-page-title">
          <h1>Sites</h1>
          <p>Operational site network overview</p>
        </div>

        <div className="admin-kpi-grid">
          <KPICard
            title="Total Sites"
            value={sites.length}
            subtitle="Configured Sites"
            icon="🏥"
          />
          <KPICard
            title="Active"
            value={activeSites}
            subtitle="Currently Active"
            icon="✅"
          />
          <KPICard
            title="Enrolled"
            value={totalEnrolled}
            subtitle="Subjects Across Sites"
            icon="👥"
          />
        </div>

        <div className="admin-table-section">
          <DataTable
            className="ctms-standard-table"
            title="Site Directory"
            columns={[
              { key: "id", label: "Site ID" },
              { key: "name", label: "Name" },
              { key: "location", label: "Location" },
              { key: "pi", label: "PI" },
              { key: "subjectsEnrolled", label: "Enrolled" },
              { key: "status", label: "Status" }
            ]}
            data={sites}
            pagination
          />
        </div>
      </div>
    </DashboardLayout>
  );
}

export default Sites;
