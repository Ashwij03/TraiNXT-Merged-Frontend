<<<<<<< HEAD:src/pages/PI/PIPageLayout.js
import PIDashboardLayout from "../../components/dashboard/pi/PIDashboardLayout";
=======
import PIDashboardLayout from "../components/PIDashboardLayout";
>>>>>>> 36a9968bf713b2a6fc05eba1b85c72608d656f05:src/PI/pages/PIPageLayout.js

function PIPageLayout({ children }) {
  return <PIDashboardLayout>{children}</PIDashboardLayout>;
}

export default PIPageLayout;
