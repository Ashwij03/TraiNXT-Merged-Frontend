<<<<<<< HEAD:src/pages/PI/PINavbar.js
import ROLES from "../../constants/roles";
import EnterpriseNavbarBase from "../../components/dashboard/shared/EnterpriseNavbarBase";

function PINavbar(props) {
 
=======
import ROLES from "../../shared/constants/roles";
import EnterpriseNavbarBase from "../../shared/components/dashboard/shared/EnterpriseNavbarBase";

function PINavbar(props) {
>>>>>>> 36a9968bf713b2a6fc05eba1b85c72608d656f05:src/PI/pages/PINavbar.js

  return (
    <EnterpriseNavbarBase
      {...props}
      layoutRole={ROLES.PI}
      liveChatPath="/pi-livechat"
      navbarClassName="pi-navbar enterprise-header--role-branded"
    />
  );
}

export default PINavbar;