<<<<<<<< HEAD:src/Components/dashboard/sitestaff/SiteStaffNavbar.js
import ROLES from "../../../constants/roles";
import EnterpriseNavbarBase from "../shared/EnterpriseNavbarBase";
========
import ROLES from "../../shared/constants/roles";
import EnterpriseNavbarBase from "../../shared/components/dashboard/shared/EnterpriseNavbarBase";
>>>>>>>> 36a9968bf713b2a6fc05eba1b85c72608d656f05:src/SiteStaff/components/SiteStaffNavbar.js

function SiteStaffNavbar(props) {
  return (
    <EnterpriseNavbarBase
      {...props}
      layoutRole={ROLES.SITE_STAFF}
      liveChatPath="/site-staff-livechat"
      navbarClassName="site-staff-navbar enterprise-header--role-branded"
    />
  );
}

export default SiteStaffNavbar;
