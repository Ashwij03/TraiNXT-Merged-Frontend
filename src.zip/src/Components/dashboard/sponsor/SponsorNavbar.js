<<<<<<<< HEAD:src/Components/dashboard/sponsor/SponsorNavbar.js
import ROLES from "../../../constants/roles";
import EnterpriseNavbarBase from "../shared/EnterpriseNavbarBase";
========
import ROLES from "../../shared/constants/roles";
import EnterpriseNavbarBase from "../../shared/components/dashboard/shared/EnterpriseNavbarBase";
>>>>>>>> 36a9968bf713b2a6fc05eba1b85c72608d656f05:src/Sponsor/components/SponsorNavbar.js

function SponsorNavbar(props) {
  return (
    <EnterpriseNavbarBase
      {...props}
      layoutRole={ROLES.SPONSOR}
      liveChatPath="/live-chat"
      navbarClassName="sponsor-navbar enterprise-header--role-branded"
    />
  );
}

export default SponsorNavbar;
