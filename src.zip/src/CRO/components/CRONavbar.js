<<<<<<<< HEAD:src/Components/dashboard/cro/CRONavbar.js
import ROLES from "../../../constants/roles";
import EnterpriseNavbarBase from "../shared/EnterpriseNavbarBase";
========
import ROLES from "../../shared/constants/roles";
import EnterpriseNavbarBase from "../../shared/components/dashboard/shared/EnterpriseNavbarBase";
>>>>>>>> 36a9968bf713b2a6fc05eba1b85c72608d656f05:src/CRO/components/CRONavbar.js

function CRONavbar(props) {
  return (
    <EnterpriseNavbarBase
      {...props}
      layoutRole={ROLES.CRO}
      liveChatPath="/cro-livechat"
      navbarClassName="cro-navbar enterprise-header--role-branded"
    />
  );
}

export default CRONavbar;
