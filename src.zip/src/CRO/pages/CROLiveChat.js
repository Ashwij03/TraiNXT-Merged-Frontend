import CROLayout from "./CROLayout";
<<<<<<< HEAD:src/pages/CRO/CROLiveChat.js
import RoleLiveChatPage from "../../components/common/RoleLiveChatPage";
import ROLES from "../../constants/roles";
import useLiveChatNavigation from "../../hooks/useLiveChatNavigation";
=======
import RoleLiveChatPage from "../../shared/components/RoleLiveChatPage";
import ROLES from "../../shared/constants/roles";
import useLiveChatNavigation from "../../shared/hooks/useLiveChatNavigation";
>>>>>>> 36a9968bf713b2a6fc05eba1b85c72608d656f05:src/CRO/pages/CROLiveChat.js

function CROLiveChat() {
  const { returnFromLiveChat, backLabel } = useLiveChatNavigation("/cro-livechat");

  return (
    <CROLayout>
      <RoleLiveChatPage
        role={ROLES.CRO}
        onBack={returnFromLiveChat}
        backLabel={backLabel}
      />
    </CROLayout>
  );
}

export default CROLiveChat;
