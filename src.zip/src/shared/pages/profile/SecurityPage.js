<<<<<<< HEAD:src/pages/shared/profile/SecurityPage.js
import DashboardLayout from "../../../components/dashboard/shared/DashboardLayout";
=======
import DashboardLayout from "../../components/dashboard/shared/DashboardLayout";
>>>>>>> 36a9968bf713b2a6fc05eba1b85c72608d656f05:src/shared/pages/profile/SecurityPage.js
import SecuritySettingsSection from "./SecuritySettingsSection";
import "../../styles/AdminPage.css";

function SecurityPage() {
  return (
    <DashboardLayout>
      <div className="admin-page">
        <div className="admin-page-title">
          <h1>Security</h1>
          <p>Manage password, authentication, and active sessions</p>
        </div>
        <SecuritySettingsSection />
      </div>
    </DashboardLayout>
  );
}

export default SecurityPage;
