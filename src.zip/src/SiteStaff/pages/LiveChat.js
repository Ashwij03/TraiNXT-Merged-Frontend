<<<<<<< HEAD:src/pages/SiteStaff/LiveChat.js
import SiteStaffDashboardLayout from "../../components/dashboard/sitestaff/SiteStaffDashboardLayout";
import RoleLiveChatPage from "../../components/common/RoleLiveChatPage";
import ROLES from "../../constants/roles";
import useLiveChatNavigation from "../../hooks/useLiveChatNavigation";
=======
import SiteStaffDashboardLayout from "../components/SiteStaffDashboardLayout";
import RoleLiveChatPage from "../../shared/components/RoleLiveChatPage";
import ROLES from "../../shared/constants/roles";
import useLiveChatNavigation from "../../shared/hooks/useLiveChatNavigation";
>>>>>>> 36a9968bf713b2a6fc05eba1b85c72608d656f05:src/SiteStaff/pages/LiveChat.js

function SiteStaffLiveChat() {
  const { returnFromLiveChat, backLabel } = useLiveChatNavigation(
    "/site-staff-livechat"
  );

  return (
    <SiteStaffDashboardLayout>
      <RoleLiveChatPage
        role={ROLES.SITE_STAFF}
        onBack={returnFromLiveChat}
        backLabel={backLabel}
      />
    </SiteStaffDashboardLayout>
  );
}

export default SiteStaffLiveChat;
